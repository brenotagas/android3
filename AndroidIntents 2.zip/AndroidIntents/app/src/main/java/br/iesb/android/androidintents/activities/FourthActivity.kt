package br.iesb.android.androidintents.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import br.iesb.android.androidintents.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_third.*
import org.jetbrains.anko.toast
import android.text.TextWatcher
import android.text.Editable
import org.jetbrains.anko.intentFor
import java.security.SecureRandom
import java.util.logging.Logger
import android.util.Patterns
import android.widget.EditText
import java.util.regex.Pattern


class FourthActivity : AppCompatActivity() {
    private val SECOND_ACTIVITY_REQUEST_CODE = 9997
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_four)

        btnClose.setOnClickListener { finish() }

        btnClose2.setOnClickListener {
            var bValido = true;

            if (editText.getText().length == 0) {//como o tamanho é zero é nulla aresposta

                editText.setError("Campo vazio");
                bValido = false;

            }
            if (!isEmailValid(editText.getText())) {
                editText.setError("Email inválido");
                bValido = false;
            }
            if (editText2.getText().length == 0 && editText2.getText().length <6) {//como o tamanho é zero é nulla aresposta

                editText2.setError("Campo vazio ou inválido");
                bValido = false;

            }
            else{

                val str = editText2.getText()
                var exp = ".*[0-9].*"
                var pattern = Pattern.compile(exp, Pattern.CASE_INSENSITIVE)
                var matcher = pattern.matcher(str)
                if (!matcher.matches()) {
                    bValido = false
                    editText2.setError("Não possui numeros");
                }

                // Password should contain at least one capital letter
                exp = ".*[A-Z].*"
                pattern = Pattern.compile(exp)
                matcher = pattern.matcher(str)
                if (!matcher.matches()) {
                    bValido = false
                    editText2.setError("Não possui Maiusculas");
                }

                exp = ".*[a-z].*"
                pattern = Pattern.compile(exp)
                matcher = pattern.matcher(str)
                if (!matcher.matches()) {
                    bValido = false
                    editText2.setError("Não possui Minusculas");
                }

                exp = ".*[~!@#\$%\\^&*()\\-_=+\\|\\[{\\]};:'\",<.>/?].*"
                pattern = Pattern.compile(exp)
                matcher = pattern.matcher(str)
                if (!matcher.matches()) {
                    bValido = false
                    editText2.setError("Não possui Caracteres especiais");
                }
            }


            if (editText3.getText().length == 0) {//como o tamanho é zero é nulla aresposta

                editText3.setError("Campo vazio");
                bValido = false;

            }

///por algum motivo essa bosta nao funciona
           // if (editText2.getText() != editText3.getText()) {

           //     editText3.setError("As senhas não correspondem";
           //     bValido = false;

           // }



            if (bValido) {
                val intent = Intent(this@FourthActivity, SecondActivity::class.java)
                startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE)
            }

        }

    }
    //funcoes
    fun isEmailValid(email: CharSequence): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }







    }
