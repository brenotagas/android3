package br.iesb.android.androidintents.activities

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.util.Log
import br.iesb.android.androidintents.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_third.*
import org.jetbrains.anko.toast
import android.text.TextWatcher
import android.text.Editable



class MainActivity : AppCompatActivity() {

    private val SECOND_ACTIVITY_REQUEST_CODE = 9999
    private val PHONE_PERMISSION_REQUEST_CODE = 9998

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        btn1.setOnClickListener {

            if( editText6.getText().length == 0){//como o tamanho é zero é nulla aresposta

                editText6.setError("Campo vazio");

            }
            if( editText7.getText().length == 0){//como o tamanho é zero é nulla aresposta

                editText7.setError("Campo vazio");

            }else if (editText7.getText().length < 10){

                editText7.setError("email invalido");

            }
             else if(!isEmailValid(editText7.getText())) {
                editText7.setError("email invalido");
            }
            else {
                val intent = Intent(this@MainActivity, SecondActivity::class.java)
                startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE)
            }
        }
               btn.setOnClickListener{
            val intent = Intent(this@MainActivity, ThirdActivity::class.java)
            startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE)
        }
        btn2.setOnClickListener{

            val intent = Intent(this@MainActivity, FourthActivity::class.java)
            startActivityForResult(intent, SECOND_ACTIVITY_REQUEST_CODE)
        }


    }

    fun isEmailValid(email: CharSequence): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    fun afterTextChanged(s: Editable) {
        // validation code goes here
    }

    private fun call() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED ) {
            toast("Ligando para o coordenador...  :)")
            val number = Uri.parse("tel:+5561999516249")
            val intent = Intent(Intent.ACTION_CALL, number)
            startActivity(intent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when (requestCode) {
            PHONE_PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call()
                } else {
                    toast(R.string.call_permission_needed)
                }
                return
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == SECOND_ACTIVITY_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            val str: String? = data?.getStringExtra("data")
            val integer: Int? = data?.getIntExtra("data2", 0)
            val double: Double? = data?.getDoubleExtra("data3", 0.0)

            Log.d("INTENT", str)
            Log.d("INTENT", integer.toString())
            Log.d("INTENT", double.toString())
        }
    }
}
