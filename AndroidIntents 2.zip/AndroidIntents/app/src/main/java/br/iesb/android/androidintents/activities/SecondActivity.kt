package br.iesb.android.androidintents.activities

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import br.iesb.android.androidintents.R
import kotlinx.android.synthetic.main.activity_second.*
import `in`.goodiebag.carouselpicker.CarouselPicker
import android.media.Image

class SecondActivity : AppCompatActivity() {


    var carouselPicker1: CarouselPicker? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)



      //  val mixItems : List<CarouselPicker.PickerItem> = List<CarouselPicker.PickerItem>(1,CarouselPicker.PickerItem)
        //val imageAdapter = CarouselPicker.CarouselViewAdapter(this, mixItems, 0)
        //carouselPicker1.setAdapter(imageAdapter)

        btnClose.setOnClickListener {
            val intent = Intent()
            intent.putExtra("data", "data 1")
            intent.putExtra("data2", 123)
            intent.putExtra("data3", 554.34)

            setResult(Activity.RESULT_OK, intent)

            finish()
        }
    }

}
